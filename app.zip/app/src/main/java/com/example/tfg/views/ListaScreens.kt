package com.example.tfg.views

enum class ListaScreens{
    LoadingScreen,
    MainScreen
}